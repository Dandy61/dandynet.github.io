<?php

return array(

    'hooks' => array(
        'user_profile_update',
        'frontpage',
        'page_is_allowed',
        'frontpage_types'
    )

);
