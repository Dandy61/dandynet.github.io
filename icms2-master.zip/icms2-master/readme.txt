InstantCMS 2
------------

Инструкция по установке: http://docs.instantcms.ru/manual/install

