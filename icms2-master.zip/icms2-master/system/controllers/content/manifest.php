<?php

    return array(

        'hooks' => array(
            'engine_start',
            'tags_search_subjects',
            'fulltext_search',
            'admin_dashboard_chart',
            'menu_content',
            'user_delete',
            'user_privacy_types',
            'sitemap_sources',
            'rss_feed_list',
            'rss_content_controller_form',
            'rss_content_controller_after_update',
            'frontpage',
            'frontpage_types',
            'ctype_relation_childs',
            'admin_content_dataset_fields_list',
            'moderation_list',
            'admin_subscriptions_list',
            'ctype_lists_context'
        )

    );
