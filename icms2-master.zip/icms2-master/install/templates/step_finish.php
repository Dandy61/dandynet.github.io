<h1><?php echo LANG_STEP_FINISH; ?></h1>

<p><?php echo LANG_FINISH_1; ?></p>
<p class="warning"><?php echo LANG_FINISH_2; ?></p>

<h3>
    <a href="<?php echo $host; ?>"><?php echo LANG_FINISH_TO_SITE; ?></a>
</h3>
